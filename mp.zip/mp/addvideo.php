<?php
  session_start();

  if($_SESSION['email'] == "")
  {
    header('location:admin_login.php');
  }
  else
  {
      //no session value present
  }

  $page='video';    

  include('include/header.php');
?>
<div style="margin-left: 16%; width:90%;">
    <ul class="breadcrumb">
      <li class="breadcrumb-item " ><a href="home.php">Home</a></li>
      <li class="breadcrumb-item " ><a href="news.php">Video</a></li>
      <li class="breadcrumb-item active" >Add Video</li>
    </ul>
  </div>
  <div style="margin-left: 20%; margin-top: 2%; width:70%; ">

  

  <form action="addvideo.php" method="post" name="categoryform" onsubmit="return validateForm();" >
    <h3>Add Video</h1><hr>
    <div class="form-group">
      <label for="exampleInputEmail1">Video Title:</label>
      <input type="text" name="video_title" class="form-control" placeholder="Enter Title">
      
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Video URL:</label>
      <input type="text" id="video_url" name="video_url" class="form-control" placeholder="Enter URL">
      
    </div>
    <button type="submit" name="add_video_btn" class="btn btn-primary">Add</button>
  </form>

  <script type="text/javascript">
    function validateForm(){
      var x=document.forms['videoform']['video_title'].value;
      if(x==""){
      alert('Title must be filled out.');
      return false;
      }
    }
</script>
</div>


<?php
 include("include/footer.php");
?>

<?php
  include('db/config.php');

  if (isset($_POST['add_video_btn'])) {
    # code...

    $category_name=$_POST['video_title'];
    $des=$_POST['video_url'];

    /*$check=mysqli_query($con,"select * from video where video_title='$video_title'");
    if (mysqli_num_rows($check)>0) {
      echo "<script>alert('This video name already taken.');</script>";
      exit();
    }*/
    
    $query=mysqli_query($con, "insert into video(video_title,video_url) values('$video_title','$video_url')");

    if ($query) {
      
      echo "<script>alert('video added successfuly.');</script>";
      echo("<script> location.href = 'video.php'; </script>");

    }
    else
    {
      echo "<script>alert('Somthing went wrong. Please try again.');</script>";
    }
  }
?>