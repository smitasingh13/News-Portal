
<script type="text/javascript" src="style/bootstrap/js/jquery-3.4.1.slim.min.js"></script>
    <script type="text/javascript" src="style/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="style/bootstrap/js/popper.min.js"></script>
      <script>window.jQuery || document.write('<script src="style/bootstrap/js/jquery.slim.min.js"></script>
      </script>
        <script src="style/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="style/bootstrap/js/feather.min.js"></script>
        <script src="style/bootstrap/js/Chart.min.js"></script>
        <script src="style/bootstrap/js/dashboard.js"></script>
        <script src="dashboard.js"></script></body>
</html>